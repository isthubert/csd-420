/* Isaac St Hubert 03/29/2026 Module 1.3
   This program displays four randomly selected images from a folder of card images */

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.stage.Stage;

import java.util.Random;

public class CardDisplay extends Application {

    private ImageView[] cardViews = new ImageView[4];
    private Random random = new Random();

    /**
     * This method creates the GUI layout, initializes the card image views, and sets up the refresh
     * button using a lambda expression to display new cards.
     * @param primaryStage
     */
    @Override
    public void start(Stage primaryStage) {

        // HBox to hold the cards
        HBox cardBox = new HBox(10);
        cardBox.setAlignment(Pos.CENTER);

        // Create ImageViews
        for (int i = 0; i < 4; i++) {
            cardViews[i] = new ImageView();
            cardViews[i].setFitHeight(150);
            cardViews[i].setPreserveRatio(true);
            cardBox.getChildren().add(cardViews[i]);
        }

        // Initial card display
        displayCards();

        // Refresh button
        Button refreshButton = new Button("Refresh");

        // Lambda expression for button click
        refreshButton.setOnAction(e -> displayCards());

        // Layout
        BorderPane pane = new BorderPane();
        pane.setCenter(cardBox);
        pane.setBottom(refreshButton);
        BorderPane.setAlignment(refreshButton, Pos.CENTER);

        Scene scene = new Scene(pane, 500, 300);

        primaryStage.setTitle("Random Cards");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * Randomly selects four cards from a deck of 52 and
     * displays their corresponding images in the ImageViews.
     */
    private void displayCards() {
        for (int i = 0; i < 4; i++) {

            int cardNumber = random.nextInt(52) + 1;

            Image cardImage = new Image("file:cards/" + cardNumber + ".png");

            cardViews[i].setImage(cardImage);
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}